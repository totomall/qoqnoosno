# Qoqnoos No
This is the first MVP version of the multilingual app with RTL and animations.